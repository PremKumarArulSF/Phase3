using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NumberTwo
{
    public class DepartmentDetails
    {
        public string DepartmentName="ECE";
        public string Degree ="BE";
        
        
        
        
    }
}