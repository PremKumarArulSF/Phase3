﻿using System;
namespace CalculatorManipulation;
class Program{
    public static void Main(string[] args)
    {
        
    }
}
