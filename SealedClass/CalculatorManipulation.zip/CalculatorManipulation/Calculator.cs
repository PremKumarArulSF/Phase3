using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Threading.Tasks;

namespace CalculatorManipulation
{
    public  class Calculator
    {
        //When use abstract keyword to abstract method ,must use abstract keyword to class.
        public abstract void Area();  
        public abstract void Volume();

        
    }
}